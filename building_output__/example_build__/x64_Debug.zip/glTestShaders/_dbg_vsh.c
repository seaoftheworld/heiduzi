#version 110

// Input vertex data, different for all executions of this shader.
attribute vec3 vertexPosition;

// Values that stay constant for the whole mesh.
uniform mat4 MVP;

void main(){
	gl_Position =  MVP * vec4(vertexPosition, 1.0);
}
